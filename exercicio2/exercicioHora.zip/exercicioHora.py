horas = int(input("Digite um valor em horas:"))

horario = horas * 60

print(horas, "hora(s) corresponde a", horario, "minutos.")