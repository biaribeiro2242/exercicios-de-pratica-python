salario = float(input("Digite o seu salário: R$"))

novo_salario = (salario - (salario * 5 /100))

print("O seu salário de R$", salario, "ficou R%", novo_salario, "com o acréscimo de 5%")