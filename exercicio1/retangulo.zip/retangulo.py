valor1 = float(input("Digite o primeiro valor:"))
valor2 = float(input("Digite o segundo valor:"))

perimetro = 2 * valor1 + 2 * valor2

area = valor1 * valor2

print("O perímetro do retângulo é:", perimetro)
print("A área do retângulo é:", area)
